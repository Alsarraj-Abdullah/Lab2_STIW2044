<?php
include_once ("dbconnect.php");
$email = $_POST['email'];



if(empty($email))
{
    authenticate();
} else {
    $sql = "SELECT * FROM USER WHERE EMAIL = '".$email."'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  header('HTTP/1.0 406 Not Acceptable');
        header('Content-Type: application/json');
$data = [ 'status' => 'taken','statusCode' => '406','timestamp' => time(), 'errorMessage' => 'Email is Taken.'];
    echo json_encode($data);
}else{
    header('Content-Type: application/json');
$data = [ 'status' => 'available','statusCode' => '200','timestamp' => time(), 'Message' => 'Email is available.'];
    echo json_encode($data);
      
}
}

function authenticate() {

    header('HTTP/1.0 400 Bad Request');
header('Content-Type: application/json');
$data = [ 'status' => 'error','statusCode' => '400','timestamp' => time(), 'errorMessage' => 'Invalid Request'];
    echo json_encode($data);
    exit;
}
?>