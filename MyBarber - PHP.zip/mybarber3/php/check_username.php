<?php
include_once ("dbconnect.php");
$Username = $_POST['username'];



if(empty($Username))
{
    authenticate();
} else {
    $sql = "SELECT * FROM USER WHERE NAME = '".$Username."'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  header('HTTP/1.0 406 Not Acceptable');
        header('Content-Type: application/json');
$data = [ 'status' => 'taken','statusCode' => '406','timestamp' => time(), 'errorMessage' => 'Username is Taken.'];
    echo json_encode($data);
}else{
    header('Content-Type: application/json');
$data = [ 'status' => 'available','statusCode' => '200','timestamp' => time(), 'Message' => 'Username is available.'];
    echo json_encode($data);
      
}
}

function authenticate() {

    header('HTTP/1.0 400 Bad Request');
header('Content-Type: application/json');
$data = [ 'status' => 'error','statusCode' => '400','timestamp' => time(), 'errorMessage' => 'Invalid Request'];
    echo json_encode($data);
    exit;
}
?>