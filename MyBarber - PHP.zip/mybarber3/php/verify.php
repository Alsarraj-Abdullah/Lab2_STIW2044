<?php
error_reporting(0);
include_once("dbconnect.php");
$email = base64_decode($_GET['email']);

$sql = "UPDATE USER SET VERIFY = '1' WHERE EMAIL = '$email'";
if ($conn->query($sql) === TRUE) {
    echo header('location: verified.php?email=' . base64_encode($email));
} else {
    echo "error";
}

$conn->close();
?>
