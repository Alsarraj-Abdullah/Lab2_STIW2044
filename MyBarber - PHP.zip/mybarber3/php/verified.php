
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>MyBarber 💈 | Email Verification</title>
	<link rel="stylesheet" href="verified.css">
</head>
<body>

	<form class="login-form" action="login.php" method="post" style="text-align: center;">
	    		<h2 class="form-title">You're verified! 💯✅</h2>
		<p>
		    We were able to verify that <b><?php echo base64_decode($_GET['email']) ?></b> is your real email address. Enjoy using MyBarber! 💈😎
		</p>
	</form>
		
</body>
</html>