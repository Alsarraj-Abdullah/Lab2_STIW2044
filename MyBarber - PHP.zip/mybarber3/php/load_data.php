<?php
include_once("dbconnect.php");
$sql ="SELECT * FROM BARBER";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    $response["Barbers"] = array();
    
    while ($row = $result ->fetch_assoc()){
        

$data = [ 'status' => 'ok','Name' =>$row['NAME'],'Address' =>$row['ADDRESS'],'Phone_Number' =>$row['PHONE'],'Price' =>$row['PRICE'],'Profile_pic' =>$row['PPIC'],'Profile_pic' =>$row['PPIC']];
array_push($response["Barbers"], $data);

    }
    header('Content-Type: application/json');
echo json_encode($response);
    
}else{
header('Content-Type: application/json');
$data = [ 'status' => 'error','statusCode' => '404','timestamp' => time(), 'errorMessage' => 'No Barbers Found'];
    echo json_encode($data);
}
?>