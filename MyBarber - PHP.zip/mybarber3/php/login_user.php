<?php
include_once("dbconnect.php");
$user = $_POST['username'];
$password = $_POST['password'];
$passwordsha = sha1($password);

$sql =sprintf("SELECT * FROM USER WHERE NAME = '%s' AND PASSWORD = '%s' AND VERIFY ='1'",$user,$passwordsha) ;
 $GetprofilePic = file_get_contents("https://sharpns.net/mybarber3/php/load_profilepic.php?username=".$user);

$result = $conn->query($sql);
if ($result->num_rows > 0) {
        header('Content-Type: application/json');
    $GetprofilePic = file_get_contents("https://sharpns.net/mybarber3/php/load_profilepic.php?username=".$user);
    $profilepic;
    $balance;
    $email;
$jsonIterator = new RecursiveIteratorIterator(
    new RecursiveArrayIterator(json_decode($GetprofilePic, TRUE)),
    RecursiveIteratorIterator::SELF_FIRST);
foreach ($jsonIterator as $key => $val) {
    if($key == 'Profile_pic') {
        $profilepic = urldecode($val);
    } 
        if($key == 'Balance') {
            
        $balance = $val;
    } 
    if($key == 'Email') {
            
        $email = $val;
    } 
}
$data = [ 'status' => 'loggedIn','statusCode' => '200','timestamp' => time(),'Profile_pic' =>$profilepic,'Balance' =>$balance,'Email' =>$email];
echo json_encode($data);
}else{
header('Content-Type: application/json');
$data = [ 'status' => 'loginFailed','statusCode' => '404','timestamp' => time(),'Profile_pic' => 'https://sharpns.net/mybarber3/images/profilepic.png','Balance' => '0', 'errorMessage' => 'No results found!'];
echo json_encode($data);
}