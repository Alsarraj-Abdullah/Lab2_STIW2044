<?php
include_once ("dbconnect.php");
//$email = $_POST['email'];
$email= $_POST['email'];
$username;
if(empty($email))
{
    http_response_code(400);
    echo "email_empty";
} else {
    $sql = "SELECT NAME FROM USER WHERE EMAIL = '".$email."'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result ->fetch_assoc()){
        $username=$row['NAME'];
$token = bin2hex(random_bytes(50));
 $sql = "INSERT INTO RECOVER_PSWD(EMAIL, TOKEN) VALUES ('$email', '$token')";
 if ($conn->query($sql) === TRUE) {
    sendEmail($name,$email,$token);
    echo "success";
} else {
     http_response_code(400);
    echo "failed";
}
    }
}else{
    http_response_code(400);
    echo "email_not_exist";
}
}
function sendEmail($name,$email,$token) {
    $to      = $email; 
    $subject = 'MyBarber - Reset Your Password'; 
    $message = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <title>MyBarber - Reset Your Password</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
</head>
<body style="margin: 0; padding: 0;">
<p>&nbsp;</p>
<table style="width: 100%; max-width: 960px; position: relative; left: 0; right: 0; margin: 0 auto; border-collapse: collapse; border-spacing: 0; font-size: 14px; line-height: 24px; color: #333; font-family: Microsoft YaHei;">
<tbody>
<tr style="height: 117px;">
<td style="padding: 20px 7.5% 0px; display: block; height: 117px;"><img src="https://sharpns.net/mybarber3/images/EmailLogo.png" width="228" height="110" /></td>
</tr>
<tr style="height: 24px;">
<td style="padding: 20px 7.5% 0px; height: 24px;">Hi '.$name.',</td>
</tr>
<tr style="height: 20px;">
<td style="padding: 20px 7.5% 0px; height: 20px;">Sorry to hear you are having trouble logging into MyBarber, Click on the following link to reset your password.</td>
</tr>
<tr style="height: 20px;">
<td style="padding: 20px 7.5% 0px; height: 20px;">
<p><a href="https://sharpns.net/mybarber3/php/reset/new_pass.php?token='.$token.'">Click here to Reset Your Password.</a></p>

</td>
</tr>
<tr style="height: 20px;">
<td style="padding: 20px 7.5% 0px; height: 20px;"><strong style="margin: 0; text-decoration: none;">If you ignore this message, your password will not be changed.</td>
</tr>
<tr style="height: 20px;">
<td style="padding: 20px 7.5% 117px; height: 20px;">Sincerely,<br />MyBarber.</td>
</tr>
</tbody>
</table>
<table style="width: 100%; max-width: 960px; position: relative; left: 0; right: 0; margin: 0 auto; text-align: center; border-collapse: collapse; border-spacing: 0; font-size: 12px; line-height: 24px; font-family: Microsoft YaHei;">
<tbody>
<tr>
<td style="display: block; height: 16px; border-top: #efefef solid 1px; background: radial-gradient(top, ellipse farthest-side, rgba(251,251,251,1), rgba(255,255,255,0));">&nbsp;</td>
</tr>
<tr>
<td style="padding-bottom: 2px;">&nbsp;</td>
</tr>
</tbody>
</table>
</body>
</html>
'; 
    $headers = 'From: noreply@sharpns.net' . "\r\n" . 
    $headers .= "MIME-Version: 1.0" . "\r\n"; 
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n"; 
    'Reply-To: '.$email . "\r\n" . 
    'X-Mailer: PHP/' . phpversion(); 
    mail($to, $subject, $message, $headers); 
}
function authenticate() {

    header('HTTP/1.0 400 Bad Request');
header('Content-Type: application/json');
$data = [ 'status' => 'error','statusCode' => '400','timestamp' => time(), 'errorMessage' => 'Invalid Request'];
    echo json_encode($data);
    exit;
}
?>