
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>MyBarber ðŸ’ˆ | Reset Password</title>
	<link rel="stylesheet" href="main.css">
</head>
<body>

	<form class="login-form" action="login.php" method="post" style="text-align: center;">
	    		<h2 class="form-title">Woo hoo! Your password has been changed! 🔐 </h2>
		<p>
		   Please be sure to memorize it or note it in a safe place. Enjoy using MyBarber! 💈😎
		</p>
	</form>
		
</body>
</html>