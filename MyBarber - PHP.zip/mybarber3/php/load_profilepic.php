<?php
include_once("dbconnect.php");
$user = htmlspecialchars($_GET["username"]);
$sql = sprintf("SELECT PPIC FROM USER WHERE NAME='%s'",$user);
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    $response[""] = array();
    while ($row = $result ->fetch_assoc()){
        header('Content-Type: application/json');
$data = [ 'status' => 'ok','statusCode' => '200','Profile_pic' =>$row['PPIC']];
echo json_encode($data);
    }
}else{
header('Content-Type: application/json');
$data = [ 'status' => 'error','statusCode' => '404','timestamp' => time(),'Profile_pic' => 'https://sharpns.net/mybarber3/images/profilepic.png', 'errorMessage' => 'Incorrect username or password.'];
    echo json_encode($data);
}
?>