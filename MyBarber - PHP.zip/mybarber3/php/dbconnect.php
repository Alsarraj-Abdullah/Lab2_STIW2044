<?php
$servername = "localhost";
$username 	= "shargtba_mybarber";
$password 	= "123qweasdzxc";
$dbname 	= "shargtba_mybarber";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>