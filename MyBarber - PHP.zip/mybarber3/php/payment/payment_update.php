<?php

include_once("dbconnect.php");
$userid = $_GET['userid'];
$amount = $_GET['amount'];
$orderid = $_GET['orderid'];
$status = "paid";
$data = array(
    'id' =>  $_GET['billplz']['id'],
    'paid_at' => $_GET['billplz']['paid_at'] ,
    'paid' => $_GET['billplz']['paid'],
    'x_signature' => $_GET['billplz']['x_signature']
);

$paidstatus = $_GET['billplz']['paid'];
if ($paidstatus=="true"){
    $paidstatus = "Success";
}else{
    echo $paidstatus;
    $paidstatus = "Failed";
}
$receiptid = $_GET['billplz']['id'];
$signing = '';
foreach ($data as $key => $value) {
    $signing.= 'billplz'.$key . $value;
    if ($key === 'paid') {
        break;
    } else {
        $signing .= '|';
    }
}
 
 
$signed= hash_hmac('sha256', $signing, 'S-51nSCuRVFsCDfakL34WWJg');
if ($signed === $data['x_signature']) {

    if ($paidstatus == "Success"){
        //echo "STATUS IN";
        if ($amount == "10"){
            $credit = '100';
        }
        if ($amount == "20"){
            $credit = '200';
        }
        if ($amount == "30"){
            $credit = '300';
        }
        if ($amount == "50"){
            $credit = '500';
        }
        if ($amount == "100"){
            $credit = '1000';
        }
        
        $sqlsearch = "SELECT * FROM USER WHERE EMAIL = '$userid'";
        $resultuser = $conn->query($sqlsearch);
        if ($resultuser->num_rows > 0) {
            while ($row = $resultuser ->fetch_assoc()){
                $currentcredit = $row["BALANCE"];
                $newcredit = $currentcredit + $credit;
                
                $newcredit;
                $sqlupdate = "UPDATE USER SET BALANCE = '$newcredit' WHERE EMAIL = '$userid'";
                $conn->query($sqlupdate);
                $sqlinsert = "INSERT INTO PAYMENT(ORDERID,USERID,TOTAL) VALUES ('$orderid','$userid','$amount')";
                $conn->query($sqlinsert);
            }
        }
    }
        echo ' <!DOCTYPE html> <html lang="en"> <head><meta http-equiv="Content-Type" content="text/html; charset=utf8"> 	 	<title>MyBarber 💈 | Payment Successful!</title> 	<link rel="stylesheet" href="verified.css"> </head> <body>  	<form class="login-form" method="post" style="text-align: center;"> 	    		<h2 class="form-title">Here\'s your Receipt!</h2> 		<p> 		    <table border=1 width=80% align=center><tr><td>Order id</td><td>'.$orderid.'</td></tr><tr><td>Receipt ID</td><td>'.$receiptid.'</td></tr><tr><td>Email to </td><td>'.$userid. ' </td></tr><td>Amount </td><td>RM '.$amount.'</td></tr><tr><td>Payment Status </td><td>'.$paidstatus.'</td></tr><tr><td>Date </td><td>'.date("d/m/Y").'</td></tr><tr><td>Time </td><td>'.date("h:i a").'</td></tr></table> 		   <p><center>Press back 🔙 button to return to the main screen.</center></p> 		</p> 	</form> 		 </body> </html>';

 } else {
    echo 'Not Match!';
}

?>