<?php
$email = 'i3boodi03@gmail.com';
$mydate =  date('dmYhis');
echo $mydate.'-'.$email;
?>